<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>&copy; 2022 <b>Annibel Jewelry & Collections</b> Made with <i class="fa fa-heart text-danger"></i> by <a href="#"><b>RoiTech</b></a></span>
        </div>
    </div>
</footer>