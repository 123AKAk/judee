
    <!-- Quick view modal start -->
    <div class="modal" id="quick_view">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-bs-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">

                    <div id="loader" style="padding: 50px;display: flex;justify-content: center;">
                        <div class="spinner-border mr-2" role="status" style="width: 1.4rem;height: 1.4rem;">
                            <span class="sr-only">Loading...</span>
                        </div>  Loading...
                    </div>

                    <div id="loadTeamPopUpForm" class="d-none">
                       
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- Quick view modal end -->